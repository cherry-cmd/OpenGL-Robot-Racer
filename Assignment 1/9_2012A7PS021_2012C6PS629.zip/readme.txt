Code is working.
To run the code, simple do python 9_2012A7PS021_2012C6PS629.py
No need of any command line arguments.
To change test case, change 1.txt in the 1st line to 2.txt, 3.txt and 4.txt